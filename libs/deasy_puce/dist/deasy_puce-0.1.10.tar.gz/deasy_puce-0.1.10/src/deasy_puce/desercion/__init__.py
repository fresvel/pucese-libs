from .desercion import InformeDesercion
